python3 - <<'PY'
from pathlib import Path
import json,hashlib,tarfile,gzip
r=Path('research/v1-unmigrated-upgrade');w=json.loads((r/'original-record-hashes.json').read_bytes());a=json.loads((r/'original-archive.json').read_bytes())
assert hashlib.sha256((r/a['path']).read_bytes()).hexdigest()==a['sha256']
with tarfile.open(r/a['path'],'r:gz') as t:
    assert set(t.getnames())==set(w)
    for name,entry in w.items():
        raw=t.extractfile(name).read();assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
old=json.loads((r/'predecessor-original-archive.json').read_bytes());assert hashlib.sha256((r/'predecessor-original-aft.tar.gz').read_bytes()).hexdigest()==old['sha256']
d=json.loads(gzip.decompress((r/'decoded/bash-1b8c0f71f2d4b6b3/receipt.json.gz').read_bytes()))
for path,v in d['sourceHashes'].items(): assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==v['sha256'],path
print('PASS: updated14 source fingerprints,',len(w),'current original records and untouched predecessor original archive')
print('CURRENT_ARCHIVE',a['sha256'],a['bytes'])
PY
git add -- packages/opencode/src/plugin-entry.test.ts packages/opencode/src/plugin/auth-loader.ts packages/opencode/src/plugin/index.ts research/v1-unmigrated-upgrade; git write-tree; git diff --stat; git diff --cached --name-only