git restore --staged -- .cortexkit/parent-inputs/v1-packed-floor-r1/opencode-linux-x64-1.17.13.tgz; python3 research/v1-unmigrated-upgrade/retain-records.py; python3 - <<'PY'
from pathlib import Path
import json,hashlib
r=Path('research/v1-unmigrated-upgrade');task='bash-087535709631f7ad'
d=json.loads((r/'decoded'/task/'receipt.json').read_bytes());m=json.loads((r/'original-aft/c1cd4f2098959f91'/task/'control/metadata.json').read_bytes())
s={'task':task,'job':m['remote']['job_id'],'tree':m['remote']['terminal']['tree_hash'],'innerExit':m['remote']['terminal']['outcome'],'outerExit':m['exit_code'],'error':d.get('error'),'liveness':[d['startupLiveness']]+[v['liveness'] for v in d['requests']]+[d['preCleanupLiveness']],'nativeErrors':[json.loads(v['body'])['info']['error'] for v in d['requests']],'negativeCalls':d['negativeCalls'],'negativeTlsEvents':d['negativeTlsEvents'],'poolHashes':[{'phase':v['name'],'sha256':hashlib.sha256((v['accountBytes'] or '').encode()).hexdigest()} for v in d['snapshots'] if v['name'] in ['before-old-writer-shutdown','before-new-host-startup','after-request-1','after-request-2','after-negative-host-cleanup']],'positiveCalls':d['positive']['calls'],'vaultCalls':d['vault']['calls'],'rowsBefore':d['migratedRows']['rows'],'rowsAfter':d['refreshedRows']['rows'],'processCleanup':[{k:p[k] for k in ['name','pid','exitCode','signal','timedOut','reaped','signalFailures']} for p in d['processes']]}
(r/'FINAL-SUMMARY.json').write_text(json.dumps(s,indent=2)+'\n')
for path,v in d['sourceHashes'].items(): assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==v['sha256'],path
print(json.dumps({k:s[k] for k in ['task','job','tree','liveness','poolHashes']},indent=2))
for t in (r/'original-aft/c1cd4f2098959f91').iterdir():
    p=t/'control/metadata.json'
    if p.exists():
        x=json.loads(p.read_bytes());c=x['command']
        if x.get('remote') and x.get('finished_at',0)>1791762700000: print('LATEST_GATE',t.name,x['exit_code'],x['remote'].get('job_id'),c[:100])
PY