python3 - <<'PY'
from pathlib import Path
import json
p=Path('research/v1-unmigrated-upgrade/decoded/bash-7142d07ffdd4777d/receipt.json');d=json.loads(p.read_bytes())
server=next(p for p in d['processes'] if p['name']=='migrated-server')
print(server['stderr'])
PY