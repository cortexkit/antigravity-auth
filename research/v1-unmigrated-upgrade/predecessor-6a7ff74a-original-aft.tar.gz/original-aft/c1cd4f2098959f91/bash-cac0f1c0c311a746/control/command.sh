python3 research/v1-unmigrated-upgrade/retain-records.py; python3 - <<'PY'
from pathlib import Path
import tarfile,json,hashlib,gzip
r=Path('research/v1-unmigrated-upgrade');m=json.loads((r/'original-record-hashes.json').read_bytes());a=json.loads((r/'original-archive.json').read_bytes())
assert hashlib.sha256((r/a['path']).read_bytes()).hexdigest()==a['sha256']
with tarfile.open(r/a['path'],'r:gz') as t:
    assert set(t.getnames())==set(m)
    for key,w in m.items():
        b=t.extractfile(key).read();assert len(b)==w['bytes'] and hashlib.sha256(b).hexdigest()==w['sha256']
mut=json.loads((r/'mutation-evidence.json').read_bytes());assert all(len(v['captured_output'])<=400 for v in mut)
raw=gzip.decompress((r/'decoded/bash-2d1909ee147087bf/receipt.json.gz').read_bytes());d=json.loads(raw)
assert raw==(r/'decoded/bash-2d1909ee147087bf/receipt.json').read_bytes()
for p,w in d['sourceHashes'].items():
    assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==w['sha256'],p
print('Verified',len(m),'byte-identical original TerminalRecord archive members;',len(d['sourceHashes']),'current source fingerprints; native receipt',len(raw),'bytes; all',len(mut),'mutation summaries bounded')
print('Archive:',a)
PY
git diff --stat; git status --short