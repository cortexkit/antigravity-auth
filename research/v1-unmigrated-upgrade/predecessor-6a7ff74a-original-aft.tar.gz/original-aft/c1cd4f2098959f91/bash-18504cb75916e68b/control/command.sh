git restore --staged -- .cortexkit/parent-inputs/v1-packed-floor-r1/opencode-linux-x64-1.17.13.tgz; python3 research/v1-unmigrated-upgrade/retain-records.py; python3 - <<'PY'
from pathlib import Path
import json
p=Path('research/v1-unmigrated-upgrade/decoded/bash-4b23835ff7c08c79/receipt.json');d=json.loads(p.read_bytes())
print('Native messages',[json.loads(r['body'])['info']['error'] for r in d['requests']])
print('Rows before',json.dumps(d['migratedRows'],indent=2));print('Rows after',json.dumps(d['refreshedRows'],indent=2))
server=next(p for p in d['processes'] if p['name']=='running-server')
print('Native process events','\n'.join(l for l in server['stderr'].splitlines() if 'message=process ' in l or 'retry' in l))
print('Positive calls',[(c['kind'],c['url'],c['host']) for c in d['positive']['calls']])
PY