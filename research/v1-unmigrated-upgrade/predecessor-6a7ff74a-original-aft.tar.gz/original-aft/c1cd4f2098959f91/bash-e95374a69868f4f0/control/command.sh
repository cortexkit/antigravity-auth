git checkout -- packages/e2e-tests/src/v1-unmigrated-upgrade-harness.ts && touch packages/e2e-tests/src/v1-unmigrated-upgrade-harness.ts; git diff --stat; git restore --staged -- .cortexkit/parent-inputs/v1-packed-floor-r1/opencode-linux-x64-1.17.13.tgz; python3 research/v1-unmigrated-upgrade/retain-records.py; python3 - <<'PY'
from pathlib import Path
import json
p=Path('research/v1-unmigrated-upgrade/decoded/bash-7142d07ffdd4777d/receipt.json');d=json.loads(p.read_bytes())
print('ERROR',d.get('error'));print('POSITIVE',d.get('positive',{}).get('body'));print('CALLS',[(c['kind'],c['url']) for c in d.get('positive',{}).get('calls',[])])
print('DNS',d.get('dnsQueries'))
print('STORE',d.get('refreshedRows'))
PY