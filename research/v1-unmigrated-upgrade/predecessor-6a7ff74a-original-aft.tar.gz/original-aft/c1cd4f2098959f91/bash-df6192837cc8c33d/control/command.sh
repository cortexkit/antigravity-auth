python3 - <<'PY'
from pathlib import Path
import json,re,hashlib
p=Path('research/v1-unmigrated-upgrade/decoded/bash-908b0af4c4425b60/receipt.json')
d=json.loads(p.read_bytes())
print('BASELINE', {k:d.get(k) for k in ['runtime','startupLiveness','preCleanupLiveness','unrelatedFixtureFailure']})
first=d['snapshots'][0]
for s in d['snapshots']:
    changed={k: {'before':first['files'].get(k),'after':s['files'].get(k)} for k in set(first['files'])|set(s['files']) if first['files'].get(k)!=s['files'].get(k)}
    print(s['name'],'POOL',hashlib.sha256((s['accountBytes'] or '').encode()).hexdigest(),'changed paths',list(changed))
    (p.parent/(s['name']+'-tree-diff.json')).write_text(json.dumps(changed,indent=2)+'\n')
trace=d['traces']['server']
lines=[l for l in trace.splitlines() if 'antigravity-accounts' in l or ('auth.json' in l and re.search(r'WRONLY|RDWR|rename|unlink',l))]
print('POOL/CREDS SYSCALLS', '\n'.join(lines))
print('NETWORK', '\n'.join(l for l in trace.splitlines() if re.search(r'\b(connect|sendmmsg|sendmsg|sendto)\(',l)))
print('PACKS', {k:v for k,v in d['packs'].items() if k in ['core','plugin','installedEntry','coreEntry']})
for request in d['tlsRequests']:
    print('TLS',request['method'],request['url'],request['rawHeaders'],request['body'][:200])
(p.parent/'running-server.syscalls').write_text(trace)
for child in d['processes']:
    (p.parent/(child['name']+'.stdout')).write_text(child['stdout'])
    (p.parent/(child['name']+'.stderr')).write_text(child['stderr'])
PY