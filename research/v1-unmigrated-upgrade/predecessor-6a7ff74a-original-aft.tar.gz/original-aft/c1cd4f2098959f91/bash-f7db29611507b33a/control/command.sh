git restore --staged -- .cortexkit/parent-inputs/v1-packed-floor-r1/opencode-linux-x64-1.17.13.tgz; python3 - <<'PY'
from pathlib import Path
import shutil, json, hashlib, base64, gzip
src=Path('/Users/ufukaltinok/.local/share/cortexkit/aft/runner/bash-tasks/c1cd4f2098959f91')
out=Path('research/v1-unmigrated-upgrade/original-aft/c1cd4f2098959f91')
manifest={}
for task in ['bash-505c05340e156421','bash-d6cba1883ab3ced8','bash-908b0af4c4425b60']:
    root=src/task
    dest=out/task
    for part in ['control/command.sh','control/metadata.json','io/stdout','io/stderr','io/exit','io/pipeline-status']:
        p=root/part
        if p.exists():
            q=dest/part;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
            manifest[str(q)]={'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
    text=(root/'io/stdout').read_text()
    encoded=text.split('UNMIGRATED_UPGRADE_RECEIPT_GZIP_BASE64_BEGIN\n',1)[1].split('\nUNMIGRATED_UPGRADE_RECEIPT_GZIP_BASE64_END',1)[0]
    raw=gzip.decompress(base64.b64decode(encoded))
    decoded=Path('research/v1-unmigrated-upgrade/decoded')/task
    decoded.mkdir(parents=True,exist_ok=True)
    (decoded/'receipt.json.gz').write_bytes(base64.b64decode(encoded))
    (decoded/'receipt.json').write_bytes(raw)
    data=json.loads(raw)
    print(task, 'error:',data.get('error'),'requests:',len(data['requests']),'tls:',len(data['tlsRequests']))
    for r in data['requests']:
        print('REQUEST',r['index'],r['status'],r['body'], 'LIVENESS',r['liveness'])
    for p in data['processes']:
        print('PROCESS',p['name'],'exit',p['exitCode'],'signal',p['signal'],'reaped',p['reaped'],'timeout',p['timedOut'])
Path('research/v1-unmigrated-upgrade/original-record-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
PY